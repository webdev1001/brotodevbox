default.elasticsearch[:deb_url] = 'https://download.elasticsearch.org/elasticsearch/elasticsearch/elasticsearch-0.90.5.deb'
default.elasticsearch[:deb_sha] = 'd25cdc971b1ef2393a620731137bae16e0d1107d49294b11c14634da0f1bb330'
