service('httpd') { action :nothing }
