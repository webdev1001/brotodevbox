name 'mysql_service_test'
version '0.0.1'

depends 'mysql'
