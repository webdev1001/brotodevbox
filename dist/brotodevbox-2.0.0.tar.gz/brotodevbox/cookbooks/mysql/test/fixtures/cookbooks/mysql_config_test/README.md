This is a test cookbook
