rbenv_script "not-much" do
  code "rake nadda"
end

