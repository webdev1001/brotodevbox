rbenv_plugin "rbenv-root-default" do
  git_url "foo.git"
end
