name "fixtures"
version "0.99.0"

depends "rbenv"
