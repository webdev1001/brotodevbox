rbenv_rehash "for-jdoe" do
  user "jdoe"
  root_path "/rooty"
end
