rbenv_rehash "defaultness"
